var foo = 'bar'
